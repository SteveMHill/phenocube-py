phenocube
=========

phenocube is an python package providing a wide range of tools for working with the phenocube environment

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`phenocube` was written by `Steven Hill <steven.hill@uni-wuerzburg.de>`_.
