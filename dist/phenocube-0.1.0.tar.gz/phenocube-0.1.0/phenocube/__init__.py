"""phenocube - phenocube is an python package providing a wide range of tools for working with the phenocube environment"""

__version__ = '0.1.0'
__author__ = 'Steven Hill <steven.hill@uni-wuerzburg.de>'
__all__ = []
